from .PawnRules import *
from .KnightRules import *
from .BishopRules import *
from .RookRules import *
from .QueenRules import *
from .KingRules import *
